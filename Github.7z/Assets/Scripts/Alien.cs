﻿using UnityEngine;
using System.Collections;
using UnityEngine;
using System.Collections;

public class Alien : MonoBehaviour
{
    private int hp = 10;
    private float timer1;
    private float timer2;
    private float y;
    private float x;

    public void Start()
    {
        timer1 = 0;
        transform.position = new Vector3(x, y);
        hp = 10;
        print(hp);
    }

    public void setX(float x)
    {
        this.x = x;
    }

    public void setY(float y)
    {
        this.y = y;
    }

    public bool decrementHp()
    {
        print(hp + " " + x);
        hp--;
        if (hp <= 0)
            return true;
        return false;
    }
    // Update is called once per frame
    public void Update()
    {

        if (hp <= 0)
        {
            print("D");
            Destroy(gameObject);
        }
        timer1 += Time.deltaTime;
        if (timer1!= timer2)
        {
            x += 0.01f;
            transform.position = new Vector3(x, y);
            timer1 = timer2;
        }
    }
}