﻿using UnityEngine;
using System.Collections;

using System.Collections.Generic;

public class Camera : MonoBehaviour
{
    public Alien prefab;
    private List<Alien> aliens = new List<Alien>();
    private float timer;
    // Use this for initialization


    void Start()
    {

    }

    public Alien newAlien(float x,float y)
    {
        Alien a= (Alien)Instantiate(prefab, new Vector3(x, y), Quaternion.identity);
        a.setX(x);
        a.setY(y);
        return a;
    }

   
    // Update is called once per frame
    void Update()
    {

        if (timer == 0.0f)
        {
             aliens.Add(newAlien(-11, 3));
             aliens.Add(newAlien(-16, 1.5f));
             aliens.Add(newAlien(-13, 0));
             aliens.Add(newAlien(-14, -1.5f));
             aliens.Add(newAlien(-11, -3));


        }

        timer += Time.deltaTime;
        if (Input.GetMouseButtonDown(0))
        {
           RaycastHit hit;
            Ray ray = UnityEngine.Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit, 100))
            {
                Alien alien = hit.collider.GetComponent<Alien>();
                if (alien.decrementHp())
                {
                    Destroy(hit.transform.gameObject);
                }


            }
        }
    }
}
